
Fish - v1 416x416
==============================

This dataset was exported via roboflow.ai on June 14, 2021 at 12:17 PM GMT

It includes 680 images.
Fish are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


